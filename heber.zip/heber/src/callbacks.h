#include <gtk/gtk.h>


void
on_buttonAjouter_clicked               (GtkWidget *objet_graphique,gpointer user_data);

void
on_buttonModifier_clicked              (GtkWidget *objet_graphique,gpointer user_data);

void
on_buttonSupprimer_clicked             (GtkWidget *objet_graphique,gpointer user_data);

void
on_buttonPageModifier_clicked          (GtkWidget *objet_graphique,gpointer user_data);

void
on_buttonPageSupprimer_clicked         (GtkWidget *objet_graphique,gpointer user_data);

void
on_buttonPageAjouter_clicked           (GtkWidget *objet_graphique,gpointer user_data);

void
on_button_Modifier_clicked             (GtkWidget *objet_graphique,gpointer user_data);

void
on_buttonAjouter_clicked               (GtkWidget *objet_graphique,gpointer user_data);

void
on_button1_clicked                     (GtkWidget *objet_graphique,gpointer user_data);

void
on_Button_reserver_clicked             (GtkWidget *objet_graphique,gpointer user_data);

void
on_button_Modifier_clicked             (GtkWidget *objet_graphique,gpointer user_data);

void
on_button_Ajouter_clicked              (GtkWidget *objet_graphique,gpointer user_data);

void
on_Button_reserver_clicked             (GtkWidget *objet_graphique,gpointer user_data);

void
on_Button_Reserver_clicked             (GtkWidget *objet_graphique,gpointer user_data);

void
on_retour_modif_heber_clicked   (GtkWidget *objet_graphique,gpointer user_data);

void
on_retour_Ajout_heber_clicked   (GtkWidget *objet_graphique,gpointer user_data);

void
on_afficher_heber_clicked     (GtkWidget *objet,gpointer user_data);         
